**To delete a custom domain name in the specified region**

Command::

  aws apigateway delete-domain-name --domain-name 'api.domain.tld' --region us-west-2

